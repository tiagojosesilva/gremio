<?php

include_once("conexao.php");

mysqli_close($conexao);

?>